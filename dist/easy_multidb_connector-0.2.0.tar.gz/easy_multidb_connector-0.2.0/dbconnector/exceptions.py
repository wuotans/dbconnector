class DatabaseConnectionError(Exception):
    """Exceção lançada quando ocorre um erro na conexão com o banco de dados"""
    pass